# Data penelitian

**Belum ada dataset pengujian atau kalibrasi pada file yang diberikan.**

Jika pengujian telah dilakukan dan izin berbagi telah diperoleh, simpan dataset yang dianonimkan beserta data dictionary, unit, kondisi eksperimen, metode rujukan, dan prosedur pembersihan. Hindari NIK, nama, tanggal lahir, foto wajah, dan identitas lain. Pisahkan data untuk fitting dan evaluasi independen.
