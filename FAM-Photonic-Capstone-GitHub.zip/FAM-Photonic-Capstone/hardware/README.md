# Hardware

Folder untuk wiring diagram, foto rangkaian, skematik, dan desain casing. **Belum ada berkas hardware yang dilampirkan** pada paket ini.

Koneksi yang tampak pada `firmware/final.ino`:

| Modul | Jalur Arduino Uno |
|---|---|
| MAX30102 | I²C hardware (SDA A4, SCL A5), tegangan harus mengikuti spesifikasi breakout |
| TCRT5000 AO | A0 |
| OLED SH1106 | Software I²C: SDA A2, SCL A3 |

Jangan menganggap tabel ini sebagai skema elektrik final: jalur daya, ground, dan level-shifting harus diverifikasi pada perangkat asli.
