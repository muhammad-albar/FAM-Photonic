# Draf SOP pengujian (belum tervalidasi)

Dokumen ini **rancangan prosedur**, bukan bukti bahwa pengujian telah dilakukan.

1. **Pemeriksaan awal:** periksa keselamatan rangkaian, tegangan modul sesuai datasheet, koneksi ground, kondisi sensor, dan kebersihan permukaan kontak.
2. **Pencatatan lingkungan:** tulis tanggal, versi firmware, kondisi cahaya, posisi jari, stabilitas suhu, dan identitas sampel berkode anonim.
3. **Verifikasi sensor:** catat nilai IR, RED, dan ADC secara terpisah; amati perilaku saat tidak ada jari dan saat ada jari.
4. **Pengukuran pembanding:** ambil hasil dari metode referensi yang sesuai menggunakan protokol, persetujuan, dan pengawasan yang diperlukan.
5. **Pengulangan:** lakukan pengukuran berulang sesuai rencana studi yang telah disetujui; simpan hasil mentah tanpa mengubahnya.
6. **Analisis:** laporkan MAE, RMSE, bias, sebaran galat, presisi/repeatability, serta keterbatasan; lakukan evaluasi pada data terpisah.
7. **Pelaporan:** bedakan hasil aktual dari target penelitian dan jangan menginterpretasikan estimasi awal sebagai hasil diagnostik.

**Penting:** prosedur pada presentasi merupakan rencana target pengujian. Rancangan ini perlu dikaji tim dan pembimbing sebelum dipakai.
