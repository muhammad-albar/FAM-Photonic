#include <Wire.h>
#include "MAX30105.h"
#include <U8g2lib.h>

MAX30105 particleSensor;

// OLED 1.3 inch SH1106
// OLED SDA = A2
// OLED SCL = A3
U8G2_SH1106_128X64_NONAME_1_SW_I2C oled(
  U8G2_R0,
  A3,              // SCL
  A2,              // SDA
  U8X8_PIN_NONE
);

#define SENSOR_AO A0

float m = 0.35;
float b = 120.0;

// ================= FUNGSI GAMBAR HATI FULL =================
void drawHeart(int x, int y) {
  oled.drawDisc(x + 6, y + 6, 5);
  oled.drawDisc(x + 16, y + 6, 5);

  oled.drawTriangle(
    x + 1,  y + 8,
    x + 21, y + 8,
    x + 11, y + 22
  );
}

// ================= FUNGSI TAMPIL OLED =================
void tampilOLED(float hemoglobin, float cholesterol, bool fingerDetected) {
  char hbText[12];
  char kolText[12];

  dtostrf(hemoglobin, 4, 1, hbText);
  dtostrf(cholesterol, 5, 1, kolText);

  oled.firstPage();
  do {
    const char* judul = "HASIL PENGUKURAN";

    // Judul
    oled.setFont(u8g2_font_5x8_tf);
    oled.drawStr(0, 8, judul);

    // Garis hanya sepanjang tulisan judul
    int panjangJudul = oled.getStrWidth(judul);
    oled.drawLine(0, 12, panjangJudul, 12);

    // Hati full putih pojok kanan atas
    drawHeart(104, 0);

    // Tampilan Hb besar
    oled.setFont(u8g2_font_7x14B_tf);
    oled.drawStr(0, 36, "Hb");

    if (fingerDetected) {
      oled.drawStr(32, 36, hbText);

      oled.setFont(u8g2_font_6x10_tf);
      oled.drawStr(85, 36, "g/dL");
    } else {
      oled.setFont(u8g2_font_6x10_tf);
      oled.drawStr(32, 34, "No Finger");
    }

    // Tampilan Kolesterol besar
    oled.setFont(u8g2_font_7x14B_tf);
    oled.drawStr(0, 58, "Kol");
    oled.drawStr(32, 58, kolText);

    oled.setFont(u8g2_font_6x10_tf);
    oled.drawStr(85, 58, "mg/dL");

  } while (oled.nextPage());
}

void setup() {
  Serial.begin(115200);

  oled.begin();
  oled.setFont(u8g2_font_5x8_tf);

  oled.firstPage();
  do {
    oled.drawStr(0, 10, "Initializing...");
  } while (oled.nextPage());

  Wire.begin();

  if (!particleSensor.begin(Wire, I2C_SPEED_FAST)) {
    Serial.println("MAX30102 tidak ditemukan!");

    oled.firstPage();
    do {
      oled.drawStr(0, 10, "MAX30102 ERROR");
      oled.drawStr(0, 22, "Cek SDA/SCL A4 A5");
    } while (oled.nextPage());

    while (1);
  }

  byte ledBrightness = 0x1F;
  byte sampleAverage = 4;
  byte ledMode = 2;
  int sampleRate = 400;
  int pulseWidth = 411;
  int adcRange = 4096;

  particleSensor.setup(
    ledBrightness,
    sampleAverage,
    ledMode,
    sampleRate,
    pulseWidth,
    adcRange
  );

  Serial.println("Sensor siap");

  oled.firstPage();
  do {
    oled.drawStr(0, 10, "Sistem Siap");
    oled.drawStr(0, 22, "Hb & Kolesterol");
    oled.drawStr(0, 34, "Letakkan jari");
  } while (oled.nextPage());

  delay(2000);
}

void loop() {
  float ir = particleSensor.getIR();
  float red = particleSensor.getRed();

  bool fingerDetected = false;
  float hemoglobin = 0;

  if (ir > 50000) {
    fingerDetected = true;

    hemoglobin = 13.5
               + ((red - 50000) / 8000.0)
               - ((ir - 50000) / 12000.0);

    if (hemoglobin < 11.0) hemoglobin = 11.0;
    if (hemoglobin > 17.5) hemoglobin = 17.5;
  }

  int adc = analogRead(SENSOR_AO);
  float cholesterol = (m * adc) + b;

  Serial.println("======================");

  if (fingerDetected) {
    Serial.print("Hemoglobin : ");
    Serial.print(hemoglobin, 2);
    Serial.println(" g/dL");
  } else {
    Serial.println("Hemoglobin : No Finger");
  }

  Serial.print("ADC TCRT   : ");
  Serial.println(adc);

  Serial.print("Kolesterol : ");
  Serial.print(cholesterol, 1);
  Serial.println(" mg/dL");

  Serial.println("======================\n");

  tampilOLED(hemoglobin, cholesterol, fingerDetected);

  delay(10000);
}