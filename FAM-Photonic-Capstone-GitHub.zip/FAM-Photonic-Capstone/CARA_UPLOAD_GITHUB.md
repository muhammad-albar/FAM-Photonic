# Cara upload repository ke GitHub

## Opsi mudah — melalui website
1. Masuk ke https://github.com/new dan buat repository bernama `FAM-Photonic-Capstone`.
2. Tentukan **Private** dulu jika izin publikasi tim/dosen belum jelas. Jangan centang *Add a README* untuk mencegah konflik saat memakai opsi Git di bawah.
3. Buka repository, pilih **Add file → Upload files**. Untuk mempertahankan seluruh struktur folder, upload folder proyek dari komputer dengan drag-and-drop jika didukung browser; jika tidak, gunakan cara Git di bawah.
4. Commit perubahan. Periksa bahwa `README.md`, folder `firmware/`, `docs/`, `hardware/`, `data/`, dan `sop/` tampil.
5. Setelah izin diperoleh, ubah menjadi Public jika diinginkan.

## Opsi paling andal — Git di komputer
Buka terminal/PowerShell di dalam folder `FAM-Photonic-Capstone` hasil ekstrak, lalu:

```bash
git init
git add .
git commit -m "Initial FAM Photonic research repository"
git branch -M main
git remote add origin https://github.com/USERNAME/FAM-Photonic-Capstone.git
git push -u origin main
```

Ganti `USERNAME` dengan username GitHub milikmu. Buat repository kosong di GitHub terlebih dahulu, lalu login GitHub jika diminta. File ZIP hanya untuk dipakai sebagai paket; **ekstrak ZIP terlebih dahulu** agar folder dan README tampil dengan benar di GitHub.
